/*
MenuMachine 2 definition file - do not edit. http://menumachine.com
2.2.1 :: Genvion%20NEW
*/
var menuName="genvion_new";
var pkg=new menuPackage(menuName,0,0,0,0,0,1,0,0,1);
/*s*/
pkg.aB("mf0e520d","",61.875,3.75,0,0,0,1,0,0,0,0,0,"h",100,"",0,0,"",0,"#273683",0,0,"black",0,0,0,"","","","",0,0,0,0,0,0,0,0,0);
pkg.aI("m76c43bc","mf0e520d",13.25,3.75,0,0,"","",/*URL*/"../../index.html","",/*URL*/"../../images/menu1.gif",/*URL*/"../../images/menu1.gif",/*URL*/"../../images/menu1.gif",0.375,0.375,0,0,"","",0,0,"Verdana,Arial,Helvetica,sans-serif","","white",0.6875,0,0,0,"white",0,1,0,0,0.3125,"",1,"","","white",0.6875,0,0,0,"white",0,1,0,0,0.3125,"",0);
pkg.aI("m44yffny","mf0e520d",5.4375,3.75,13.25,0,"","",/*URL*/"../../index.html","",/*URL*/"../../images/menu2.gif",/*URL*/"../../images/menu2-over.gif",/*URL*/"../../images/menu2.gif",0.375,0.375,0,0,"","",1,1);
pkg.aI("m28fb71v","mf0e520d",8.125,3.75,18.6875,0,"","",/*URL*/"../../about.html","",/*URL*/"../../images/menu5.gif",/*URL*/"../../images/menu5-over.gif",/*URL*/"../../images/menu5.gif",0.375,0.375,0,0,"","",2,1);
pkg.aI("m28fb71u","mf0e520d",7.9375,3.75,26.8125,0,"","",/*URL*/"../../services.html","",/*URL*/"../../images/menu4.gif",/*URL*/"../../images/menu4-over.gif",/*URL*/"../../images/menu4.gif",0.375,0.375,0,0,"","",3,1);
pkg.aI("m28fb71t","mf0e520d",7.4375,3.75,34.75,0,"","",/*URL*/"../../facility.html","",/*URL*/"../../images/menu3.gif",/*URL*/"../../images/menu3-over.gif",/*URL*/"../../images/menu3.gif",0.375,0.375,0,0,"","",4,1);
pkg.aI("m28fb71w","mf0e520d",7.875,3.75,42.1875,0,"","",/*URL*/"../../careers.html","",/*URL*/"../../images/menu6.gif",/*URL*/"../../images/menu6-over.gif",/*URL*/"../../images/menu6.gif",0.375,0.375,0,0,"","",5,1);
pkg.aI("m28fb71x","mf0e520d",11.8125,3.75,50.0625,0,"","",/*URL*/"../../contact.html","",/*URL*/"../../images/menu7.gif",/*URL*/"../../images/menu7-over.gif",/*URL*/"../../images/menu7.gif",0.375,0.375,0,0,"","",6,1);
pkg.aB("m28fb71y","m28fb71u",10.25,6.1875,25.75,3.8125,-17,61,353,353,3,3,0,"v",100,"",0.0625,0,"",0,"#273683",0,0,"#AAAAAA",0,0,0,"",/*URL*/"images/arrmodsmlright_white.gif",/*URL*/"images/arrmodsmlright_white.gif",/*URL*/"images/arrmodsmlright_white.gif",0.1875,0.375,0.625,0.625,0,0,0,0,0);
pkg.aI("m28fb71z","m28fb71y",10.25,1.5,0,0,"Research & Development","",/*URL*/"../../development.html","","","","",0.375,0.375,0,0,"","",0,0,"Verdana,Arial,Helvetica,sans-serif","red","white",0.6875,0,0,0,"red",0,0,0,0.75,0.375,"",1,_,"red","black",_,_,_,_,_,_,0,_,0.75,0.375,_,0);
pkg.aI("m28fb720","m28fb71y",10.25,1.5,0,1.5625,"Manufacturing","",/*URL*/"../../manufacturing.html","","","","",0.375,0.375,0,0,"","",1,1);
pkg.aI("m28fb721","m28fb71y",10.25,1.5,0,3.125,"Packaging","",/*URL*/"../../packaging.html","","","","",0.375,0.375,0,0,"","",2,1);
pkg.aI("m28fb722","m28fb71y",10.25,1.5,0,4.6875,"Laboratory","",/*URL*/"../../laboratory.html","","","","",0.375,0.375,0,0,"","",3,1);
/*f*/
__menuHolder.aP(pkg);
var __l=__br.un?"un.js":(__br.ie?"iedom.js":(__br.dom?"w3cdom.js":""));
document.write(_sTs+mmfolder+"core/"+__l+_sTe);